bulan=str("januari")
inputuser=str(input("tebak bulan apa?: "))
if inputuser==bulan:
    print ("yey bener")
else:
    print ("salah kocak")