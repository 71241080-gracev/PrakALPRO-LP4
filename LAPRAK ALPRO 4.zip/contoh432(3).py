nilai=int(input("masukkan nilai: "))
if nilai>=90:
    print ("gud gud")
elif nilai>=70:
    print ("mayan")
else:
    print("bljr yg bner deck")
    