usia=int(input("masukkan usia anda: "))
if usia < 20:
    print ("masih bocil")
