n=4
x=10
if n is not x:
    print ("true")
else:
    print ("false")
    