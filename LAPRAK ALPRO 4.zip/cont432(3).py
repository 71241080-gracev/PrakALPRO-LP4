usia=int(input("masukkan usia anda: "))
print ("masih bocil") if usia < 20