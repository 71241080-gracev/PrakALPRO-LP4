jam=10
if jam<=10:
    print ("true")
