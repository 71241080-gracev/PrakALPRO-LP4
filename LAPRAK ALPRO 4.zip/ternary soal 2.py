bilangan = int(input("Masukkan suatu bilangan: "))
print ("Positif") if bilangan > 0 else print ("Negatif") if bilangan < 0 else print ("Nol")
