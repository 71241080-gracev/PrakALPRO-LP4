n=3
if n!=4:
    print ("true")