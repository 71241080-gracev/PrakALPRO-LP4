inputgaji=input("Masukkan gajimu: ")

try:
    gaji=int(inputgaji)
except:
    print ("masukkan gaji dalam bentuk angka")
    
if gaji>3000000:
    print ("di atas umr")
elif gaji>=1000000:
    print ("mepet umr")
else:
    print ("gajimu dikorup")