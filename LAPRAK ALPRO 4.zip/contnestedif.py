nilai=int(input("masukkan nilai anda: "))
if nilai >=75:
    print("lulus")
    if nilai >=95:
        print("sangat baik")
    else:
        print("baik")
else:
    print("tidak lulus")
    